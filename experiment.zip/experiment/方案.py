###自己的idea：分组用牛顿插值法
import time
import random
import numpy as np
import hashlib

def generate_list_a(n, m):#生成初始列表，n为长度，m为组数
    nums = list(range(10))
    result = []
    for i in range(0, n, m):
        current_group = random.sample(nums, m)
        result.extend(current_group)
    return result

def generate_list_b(n, m):#生成初始列表，n为长度，m为组数
    nums = list(range(10,21))
    result = []
    for i in range(0, n, m):
        current_group = random.sample(nums, m)
        result.extend(current_group)
    return result

def prg(seed, size):
    num_bytes = np.prod(size) * 8
    random_bytes = b''
    counter = 0
    while len(random_bytes) < num_bytes:
        counter_bytes = counter.to_bytes(4, 'big')
        random_bytes += hashlib.sha256(seed + counter_bytes).digest()
        counter += 1
    
    arr = np.frombuffer(random_bytes[:num_bytes], dtype=np.float64)

    arr = np.nan_to_num(arr / np.max(np.abs(arr)))
    
    return arr.reshape(size)

def blind_gradient(grad, client_id, seeds_matrix):
    n_clients = len(seeds_matrix)
    blinded_grad = grad.copy()
    
    # 添加与更高ID客户端的PRG结果
    for j in range(client_id + 1, n_clients):
        seed = seeds_matrix[client_id][j]
        blinded_grad += prg(seed, grad.shape)
    
    # 减去与更低ID客户端的PRG结果
    for j in range(0, client_id):
        seed = seeds_matrix[client_id][j]
        blinded_grad -= prg(seed, grad.shape)
    
    return blinded_grad

class NewtonInterpolator:
    def __init__(self, x_nodes, y_nodes):
        self.x_nodes = x_nodes
        self.diff_table = self._build_diff_table(y_nodes)
        
    
    def _build_diff_table(self, y_nodes):
        n = len(self.x_nodes)
        diff_table = [np.array(y_nodes, dtype=np.float64).copy()]
        
        for i in range(1, n):
            row = []
            for j in range(n - i):
                numerator = diff_table[i-1][j+1] - diff_table[i-1][j]
                denominator = self.x_nodes[j+i] - self.x_nodes[j]
                row.append(numerator / denominator)
            diff_table.append(np.array(row))
        return diff_table
    
    def evaluate(self, x):
        result = self.diff_table[0][0]
        cumulative_product = 1.0
        for i in range(1, len(self.diff_table)):
            cumulative_product *= (x - self.x_nodes[i-1])
            result += self.diff_table[i][0] * cumulative_product
        return result

M=4
num_gra=100000
interpolators_local = []#用来存储差商表,本地数据
interpolators_agg = []#用来存储差商列表，聚合之后
a_list = generate_list_a(num_gra, M)
b_list = generate_list_b(num_gra+num_gra//M, M+1)
res_gra = [0]*num_gra
Fb_list = []
r_list = [random.randint(21, 30) for _ in range(100000//M)]#随机数(横坐标)
R_list = [random.randint(0, 9) for _ in range(100000//M)]#随机数(纵坐标)
V1 = 0
S1 = 0

np.random.seed(42)
n_clients = 10
grad_shape = (100000,)
seeds_matrix = [[None] * n_clients for _ in range(n_clients)]
for i in range(n_clients):
      for j in range(i + 1, n_clients):
          # 生成共享种子 (实际应用中应安全共享)
          seed = np.random.bytes(32)  # 256位种子
          seeds_matrix[i][j] = seed
          seeds_matrix[j][i] = seed
g_list_plain = np.random.randn(*grad_shape)#模拟梯度
g_list = blind_gradient(g_list_plain, 0, seeds_matrix)#盲化

#加密部分，即分组做牛顿插值法，一组打包成一个值，在解密部分先解包
start_time1=time.time()
for i in range(100000//M):
    a_group = a_list[i*M : i*M + M]#取一组M个
    g_group = g_list[i*M : i*M + M]#梯度也取一组M个
    b_group = b_list[i*(M+1) : i*(M+1) + (M+1)]
    a_group.append(r_list[i])#末尾添加一个点，现在一组是M+1个点
    g_group=np.append(g_group,R_list[i])
    interpolator = NewtonInterpolator(a_group,g_group)#第i组的差商表
    interpolators_local.append(interpolator)#存入到差商列表中
    new_list = [interpolators_local[i].evaluate(x) for x in b_group]
    new_list_toint=[int(x) for x in new_list]
    Fb_list.append(new_list_toint)
end_time1 = time.time()
exctime1=end_time1-start_time1

startime2=time.time()  
#解密部分，先解包聚合值，然后验证，验证通过就恢复梯度值
for i in range(100000//M):
    test_list = [random.randint(21, 30) for _ in range(10)]
    b_group = b_list[i*(M+1) : i*(M+1) + (M+1)]
    interpolator = NewtonInterpolator(b_group,Fb_list[i])#相当于Fb
    interpolators_agg.append(interpolator)
    V_list = [interpolators_agg[i].evaluate(x) for x in test_list]
    V1 = V1 + sum(V_list)       
    S_list = [interpolators_local[i].evaluate(x) for x in test_list]
    S1 = S1 + sum(S_list)
if(V1!= S1):
    for i in range(100000//M):
        a_group = a_list[i*M : i*M + M]
        res_gra[i*M:i*M+M] = [interpolators_agg[i].evaluate(x) for x in a_group]#解密梯度值
endtime2=time.time()
exctime2=endtime2-startime2
print(f"加密总耗时:{exctime1:.4f}")
print(f"解密总耗时:{exctime2:.4f}")  