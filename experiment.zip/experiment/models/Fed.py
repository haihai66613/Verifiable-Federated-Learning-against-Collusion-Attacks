    #!/usr/bin/env python
# -*- coding: utf-8 -*-
# Python version: 3.6

import copy
import torch
from torch import nn

#传入的w参数，是所有参与训练客户端的局部权重列表
def FedAvg(w):
    #建一个变量 w_avg，并将其初始化为参数列表 w 的第一个元素w[0]的深度副本
    w_avg = copy.deepcopy(w[0])
    # 遍历w_avg的每个key
    for k in w_avg.keys():
        # 遍历参数列表 w 的剩余元素，从第二个元素开始
        for i in range(1, len(w)):
            # 将参数列表 w 中的每个元素的键 k 对应的值加到 w_avg[k]上，在每个键上累积了所有参数的值
            w_avg[k] += w[i][k]
            # 对累积的值进行平均，将其除以参数列表 w 的长度。torch.div() 函数用于执行元素级除法。
        w_avg[k] = torch.div(w_avg[k], len(w))
    return w_avg

#举个例子
student1 = {
    'name': 'John',
    'age': 18,
    'grade': '12th',
    'school': 'ABC High School'
}

student2 = {
    'name': 'Jane',
    'age': 17,
    'grade': '11th',
    'school': 'XYZ High School'
}
student3 = {
    'name': 'hidisan',
    'age': 23,
    'grade': '14th',
    'school': 'NB High School'
}

w = [student1, student2, student3]
#那w_avg一开始等于student1，
w_avg = copy.deepcopy(w[0])
#经过遍历累加得到
w_avg = {'name': 'JohnJanehidisan',
         'age': 58,
         'grade': '12th11th14th',
         'school': 'ABC High SchoolXYZ High SchoolNB High School'}
#然后经过torch.div，执行元素级除法