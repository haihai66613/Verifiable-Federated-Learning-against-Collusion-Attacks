import numpy as np
import random
import math
from sympy import symbols, interpolate
from utils.sampling import mnist_iid, mnist_noniid, cifar_iid
from utils.options import args_parser
from models.Update import LocalUpdate
from models.Nets import MLP, CNNMnist, CNNCifar
from models.Fed import FedAvg
from models.test import test_img
import torch
import os
os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'

def generate_coprime_numbers(m):
    # 生成质数列表
    def sieve_of_eratosthenes(limit):
        sieve = [True] * (limit + 1)
        sieve[0] = sieve[1] = False
        for i in range(2, int(limit ** 0.5) + 1):
            if sieve[i]:
                for j in range(i * i, limit + 1, i):
                    sieve[j] = False
        return [i for i in range(2, limit + 1) if sieve[i]]
    # 生成一定数量的质数
    limit = 100  # 可以调整质数范围
    primes = sieve_of_eratosthenes(limit)
    # 随机选择m个质数
    g_list = random.sample(primes, m)
    return g_list

def extended_gcd(a, b):
    if b == 0:
        return a, 1, 0
    gcd, x1, y1 = extended_gcd(b, a % b)
    x = y1
    y = x1 - (a // b) * y1
    return gcd, x, y

def mod_inverse(a, m):
    gcd, x, y = extended_gcd(a, m)
    if gcd != 1:
        raise Exception(f"{a}和{m}没有逆元")
    else:
        return x % m

def chinese_remainder_theorem(result, g_list):
        x = 0
        N = 1  # N是所有模数的乘积

        # 计算所有模数的乘积N
        for n in g_list:
            N *= n
        # 对每个方程
        for ai, ni in zip(result, g_list):
            # 计算Ni = N / ni
            Ni = N // ni
            # 计算Ni对ni的逆元
            inv = mod_inverse(Ni, ni)
            # 根据公式求解
            x += ai * Ni * inv
        # 返回x mod N
        return x % N


def lagrange_interpolate1(a_list, v_list, b_list):
        n = len(a_list)
        results = []  # 用于存储每个x值的插值结果
        for x in b_list:  # 对每个x值进行插值计算
            result = 0.0
            for i in range(n):
                term = v_list[i]
                for j in range(n):
                    if i != j:
                        term *= (x - a_list[j]) / (a_list[i] - a_list[j])
                result += term
            results.append(result)
        return results  # 返回包含所有插值结果的数组

def lagrange_interpolate2(a_list, v_list, x):
    """
    拉格朗日插值法计算插值点 x 处的函数值
    """
    n = len(a_list)
    result = 0.0
    for i in range(n):
        term = v_list[i]
        for j in range(n):
            if i != j:
                term *= (x - a_list[j]) / (a_list[i] - a_list[j])
        result += term
    return result


class NewtonInterpolator:
    def __init__(self, x_nodes, y_nodes):
        self.x_nodes = x_nodes
        self.diff_table = self._build_diff_table(y_nodes)

    def _build_diff_table(self, y_nodes):
        """
        构建牛顿差商表（完整实现）
        """
        n = len(self.x_nodes)
        diff_table = [np.array(y_nodes, dtype=np.float64).copy()]

        for i in range(1, n):
            row = []
            for j in range(n - i):
                numerator = diff_table[i - 1][j + 1] - diff_table[i - 1][j]
                denominator = self.x_nodes[j + i] - self.x_nodes[j]
                row.append(numerator / denominator)
            diff_table.append(np.array(row))
        return diff_table

    def evaluate(self, x):
        """
        使用霍纳法则计算插值结果
        """
        result = self.diff_table[0][0]
        cumulative_product = 1.0
        for i in range(1, len(self.diff_table)):
            cumulative_product *= (x - self.x_nodes[i - 1])
            result += self.diff_table[i][0] * cumulative_product
        return result

def binary_pack(numbers, bit_width):
        packed = 0
        for num in numbers:
            mask = (1 << bit_width) - 1
            if num < 0:
                num_complement = ((abs(num) ^ mask) + 1) & mask
            else:
                num_complement = num & mask
            packed = (packed << bit_width) | num_complement
        return packed

def binary_unpack(packed, bit_width, n_numbers):
        numbers = []
        mask = (1 << bit_width) - 1
        for _ in range(n_numbers):
            part = packed & mask
            if part >> (bit_width - 1):
                part = -((~part + 1) & mask)
            numbers.append(part)
            packed >>= bit_width
        return list(reversed(numbers))

def binary_add(p1, p2, bit_width, n_numbers):
        result = 0
        mask = (1 << bit_width) - 1
        for _ in range(n_numbers):
            # 取最低位对应的数
            a = p1 & mask
            b = p2 & mask

            # 补码 -> 原码
            if a >> (bit_width - 1):
                a = -((~a + 1) & mask)
            if b >> (bit_width - 1):
                b = -((~b + 1) & mask)

            # 相加并重新补码
            s = a + b
            s_masked = ((abs(s) ^ mask) + 1) & mask if s < 0 else s & mask

            # 放到结果中
            result |= s_masked << (_ * bit_width)

            # 右移，准备处理下一组
            p1 >>= bit_width
            p2 >>= bit_width

        return result


