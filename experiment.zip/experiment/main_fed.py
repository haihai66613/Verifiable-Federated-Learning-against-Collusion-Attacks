#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Python version: 3.6
import os
import time
from models.Ver import  NewtonInterpolator

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

#标准库文件的调用
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import copy #用于联邦学习全局模型的复制过程
import numpy as np
from torchvision import datasets, transforms
import torch
import random

#自定义文件的调用
from utils.sampling import mnist_iid, mnist_noniid, cifar_iid
from utils.options import args_parser
from models.Update import LocalUpdate
from models.Nets import MLP, CNNMnist, CNNCifar
from models.Fed import FedAvg
from models.test import test_img

if __name__ == '__main__':
    #调用 utils 文件夹中的 option.py 函数，其中args_parser()是一种命令行参数。
    args = args_parser()
    #用来选择程序运行设备，如果有GPU资源则调用服务器的GPU做运算，否则就用CPU运行
    args.device = torch.device('cuda:{}'.format(args.gpu) if torch.cuda.is_available() and args.gpu != -1 else 'cpu')

    #数据集的下载和划分
    if args.dataset == 'mnist':
        #trans_mnist是用来定义我们对图片的处理方式，比方这里就是将图片转化为tensor类型后进行归一化操作
        trans_mnist = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
        #dataset_train和dataset_test的划分都是调用datasets这个库，将数据集内容下载到了我们设定存放数据的data文件夹的mnist和cifar文件夹里
        dataset_train = datasets.MNIST('../data/mnist/', train=True, download=True, transform=trans_mnist)
        dataset_test = datasets.MNIST('../data/mnist/', train=False, download=True, transform=trans_mnist)

        #通过定义不同的数据划分方式将数据分为 iid 和 non-iid 两种，用来模拟测试 FedAvg 在不同场景下的性能
        #mnist_iid函数接受MNIST训练集和用户数量作为参数，返回的是一个字典类型dict_users，key值是用户id，values是用户拥有的图片id
        if args.iid:
            dict_users = mnist_iid(dataset_train, args.num_users)
        else:
            dict_users = mnist_noniid(dataset_train, args.num_users)
    elif args.dataset == 'cifar':
        trans_cifar = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
        dataset_train = datasets.CIFAR10('../data/cifar', train=True, download=True, transform=trans_cifar)
        dataset_test = datasets.CIFAR10('../data/cifar', train=False, download=True, transform=trans_cifar)
        if args.iid:
            dict_users = cifar_iid(dataset_train, args.num_users)
        else:
            exit('Error: only consider IID setting in CIFAR10')
    else:
        exit('Error: unrecognized dataset')
    img_size = dataset_train[0][0].shape

    # 根据命令行参数args.model和args.dataset来选择模型类型和数据集类型
    # 选择我们要使用的在 models 文件夹下 Nets.py 所定义过的神经网络模型，net_glob 就接收返回的网络类型
    if args.model == 'cnn' and args.dataset == 'cifar':
        net_glob = CNNCifar(args=args).to(args.device)
    elif args.model == 'cnn' and args.dataset == 'mnist':
        net_glob = CNNMnist(args=args).to(args.device)
    elif args.model == 'mlp':
        len_in = 1
        for x in img_size:
            len_in *= x
        net_glob = MLP(dim_in=len_in, dim_hidden=200, dim_out=args.num_classes).to(args.device)
    else:
        exit('Error: unrecognized model')
    print(net_glob)


    def generate_list_a(n, m):  # 生成初始列表，n为长度，m为组数
        nums = list(range(10))
        result = []
        for i in range(0, n, m):
            current_group = random.sample(nums, m)
            result.extend(current_group)
        return result

    def generate_list_b(n, m):  # 生成初始列表，n为长度，m为组数
        nums = list(range(10, 21))
        result = []
        for i in range(0, n, m):
            current_group = random.sample(nums, m)
            result.extend(current_group)
        return result


#########################################一些全局变量
    bit_width=16 #二进制打包的位数
    M=4 #每组的元素个数
    num_gra=100000 #梯度个数
    a_list = generate_list_a(num_gra, M) # 常数序列ai，所有客户端共享
    b_list = generate_list_b(num_gra+num_gra//M, M+1)  # 常数序列bi，所有客户端共享
    locals_list=[] #用于保存每个客户端的local
    all_r_list=[] #每个人的r列表
    agg = [[0,0,0,0,0] for _ in range(num_gra//M)]#保存聚合结果
    agg_res = [0] * (num_gra // M)  # 解密的时候保存结果
    interpolators_agg = [] ##聚合后的拉格朗日插值
    V=0
    S=0



    #神经网络进行训练
    net_glob.train()
    # 复制当前全局模型net_glob的权重
    w_glob = net_glob.state_dict()
    #训练过程中的损失函数列表
    loss_train = []
    #存储交叉验证的损失和准确率列表
    cv_loss, cv_acc = [], []
    #存储上一次迭代的验证集损失值和计数器，这些变量通常用于早停策略，在验证集损失不再下降时停止训练，以防止过拟合
    val_loss_pre, counter = 0, 0
    net_best = None
    best_loss = None
    #用于存储验证集准确率和模型权重，常用于跟踪验证集上的性能变化和保存模型的快照
    val_acc_list, net_list = [], []
    # 如果为真，表示要对所有客户端进行聚合
    if args.all_clients:
        print("Aggregation over all clients")
        w_locals = [w_glob for i in range(args.num_users)]
    for iter in range(args.epochs):
        # 存储每个客户端的局部损失值
        loss_locals = []
        # 如果不是所有客户，创建列表w_locals存储每个客户端的局部权重
        if not args.all_clients:
            w_locals = []
        # 根据命令行参数args.frac和args.num_users，确定参与本轮训练的客户端数量m
        m = max(int(args.frac * args.num_users), 1)
        # 随机选择m个客户端的索引，存储在idxs_users中
        idxs_users = np.random.choice(range(args.num_users), m, replace=False)
        # 遍历被选的客户端
        for idx in idxs_users:
            # 执行本地更新
            local = LocalUpdate(args=args, dataset=dataset_train, idxs=dict_users[idx],M=4)
            # 传入当前的全局模型net_glob的副本，并获取更新后的权重w和局部损失loss
            w, loss = local.train(net=copy.deepcopy(net_glob).to(args.device))
            # 如果是所有客户端，将更新后的权重w赋值给w_locals的对应索引位置
            if args.all_clients:
                w_locals[idx] = copy.deepcopy(w)
            else:
                # 否则，添加权重w到w_locals列表中
                w_locals.append(copy.deepcopy(w))
                # 将局部损失loss添加到loss_locals列表中
            loss_locals.append(copy.deepcopy(loss))
########################################################################################################加密部分
            start_time1=time.time()
            for i in range(100000//M):
                a_group = a_list[i * M: i * M + M] #从a中取M个做为横坐标
                g_group = local.g_list[i * M: i * M + M] #从私有g中取M个做为纵坐标
                b_group = b_list[i * (M + 1): i * (M + 1) + (M + 1)] #另外取M+1个点
                a_group.append(local.r_list[i])
                g_group.append(local.R_list[i]) ##在每组的末尾加一个验证点
                interpolator = NewtonInterpolator(a_group, g_group) #构造插值
                local.interpolators_local.append(interpolator) ##插值表集合
                new_list = [local.interpolators_local[i].evaluate(x) for x in b_group] ##用b列表另外选择M+1个点
                new_list_toint = [int(x) for x in new_list] ##转成整型
                local.Fb_list.append(new_list_toint)##Fb_list存储M个new_list_toint
            end_time1 = time.time()
            execution_time = end_time1 - start_time1
            print(f"Total execution time1: {execution_time} seconds")
########################################################################################################聚合部分
            locals_list.append(local)
            all_r_list.append(local.r_list)

            agg=[[a + b for a, b in zip(row_a, row_b)] for row_a,row_b in zip(agg,local.Fb_list)]##聚合就是把每个客户端的Fb_list按位相加
#######################################################################################################解密部分
        start_time2 = time.time()
        for i in range(100000//M): #算验证值V
            b_group = b_list[i * (M + 1): i * (M + 1) + (M + 1)]
            interpolator = NewtonInterpolator(b_group, agg[i])
            interpolators_agg.append(interpolator)
            r_group= [group[i] for group in all_r_list]
            V_list = [interpolators_agg[i].evaluate(x) for x in r_group]
            V=V+sum(V_list)

        for i in range(m): #算验证值S
            for j in range(100000//M):
                r_group = [group[j] for group in all_r_list]
                s_list = [locals_list[i].interpolators_local[j].evaluate(x) for x in r_group]
                locals_list[i].S_list.append(sum(s_list))

        for i in range(m):
            S=S+sum(locals_list[i].S_list)

        for i in range(100000 // M):
            a_group = a_list[i * M: i * M + M]
            agg_res[i * M:i * M + M] = [interpolators_agg[i].evaluate(x) for x in a_group]  # 解密梯度值
        end_time2 = time.time()
        execution_time = end_time2 - start_time2
        print(f"Total execution time2: {execution_time} seconds")
##########################################################################################################


        # update global weights
        # 使用FedAvg函数对w_locals进行聚合，得到更新后的全局权重w_glob
        w_glob = FedAvg(w_locals)
        # copy weight to net_glob
        # 将更新后的全局权重w_glob加载到net_glob中，以便在下一轮迭代中使用
        net_glob.load_state_dict(w_glob)
        # print loss
        # 计算本轮训练的平均损失，并添加到loss_train列表中
        loss_avg = sum(loss_locals) / len(loss_locals)
        print('Round {:3d}, Average loss {:.3f}'.format(iter, loss_avg))
        loss_train.append(loss_avg)
    #完成了以下几个任务：1、绘制损失函数曲线并保存为图片 2、将全局模型设置为评估模式 3、在训练集和测试集上对模型进行测试，计算准确率和损失 4、打印训练准确率和测试准确率。
    # plot loss curve
    plt.figure()
    plt.plot(range(len(loss_train)), loss_train)
    plt.ylabel('train_loss')
    plt.savefig('./save/fed_{}_{}_{}_C{}_iid{}.png'.format(args.dataset, args.model, args.epochs, args.frac, args.iid))

    # testing
    net_glob.eval()
    acc_train, loss_train = test_img(net_glob, dataset_train, args)
    acc_test, loss_test = test_img(net_glob, dataset_test, args)
    print("Training accuracy: {:.2f}".format(acc_train))
    print("Testing accuracy: {:.2f}".format(acc_test))





